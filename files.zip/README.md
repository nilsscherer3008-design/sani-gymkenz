# Sani AG – Web Push (echte Benachrichtigungen mit Ton, kostenlos)

Das hier sorgt dafür, dass bei einem Notfall eine **echte Push-Benachrichtigung**
kommt (mit Ton/Vibration) — auch wenn die App gerade zu ist. Kostenlos, kein
Konto bei einem SMS-Anbieter nötig. Braucht aber trotzdem kurz Internet, wenn
der Notfall ausgelöst wird (bei komplett totem Empfang: siehe SMS-Backup in
der App).

## Was hier drin ist

```
supabase-push/
└── functions/
    └── send-emergency-push/
        └── index.ts     ← die eigentliche Funktion
```

## Voraussetzungen

- Node.js (falls noch nicht installiert: https://nodejs.org, "LTS" Version)
- Ein Terminal

## Einrichtung (einmalig, ca. 15 Minuten)

### 1. Supabase CLI installieren
```
npm install -g supabase
```

### 2. Bei Supabase einloggen
```
supabase login
```
(öffnet einen Browser zum Anmelden mit eurem Supabase-Konto)

### 3. Diesen Ordner mit eurem Supabase-Projekt verbinden
In diesem `supabase-push`-Ordner:
```
supabase link --project-ref ljxvgqvutawlyjzuhmgc
```

### 4. Geheimnisse setzen
Die Funktion braucht 3 Werte, die NIE im Quelltext stehen dürfen:

```
supabase secrets set VAPID_PUBLIC_KEY=BHl2BlD_PfasHuhqjw_5vXDRggPT9GxQMhlgZ2TrZyPg755l2bMto0-KBP9MrguSZj1ozVWLR8p04POVhHdIaH0
supabase secrets set VAPID_PRIVATE_KEY=mNBBJre_5YC9tv7HwvYUZToMrQnYrdqsjFDqLm_QAF8
supabase secrets set WEBHOOK_SECRET=P6Op4W9cGw0VjeNY5GLyjxbB8lcPWCi7
```

⚠️ **Der VAPID_PRIVATE_KEY und das WEBHOOK_SECRET sind geheim** — nicht
weitergeben, nicht in ein öffentliches GitHub-Repo committen. Der
VAPID_PUBLIC_KEY dagegen ist bewusst nicht geheim (steht auch in `index.html`).

Falls ihr das WEBHOOK_SECRET ändern wollt: einfach eine eigene
Zufallszeichenkette nehmen, aber dieselbe dann auch oben in
`supabase-security.sql` bei `x-webhook-secret` eintragen (an beiden Stellen
muss exakt derselbe Wert stehen).

`SUPABASE_URL` und `SUPABASE_SERVICE_ROLE_KEY` müsst ihr NICHT setzen — die
stellt Supabase der Funktion automatisch zur Verfügung.

### 5. Funktion deployen
```
supabase functions deploy send-emergency-push --no-verify-jwt
```
`--no-verify-jwt` ist hier wichtig, weil die Funktion vom Datenbank-Trigger
aufgerufen wird, nicht direkt von der App — der Trigger hat kein normales
Nutzer-Login-Token dabei. Der Schutz läuft stattdessen über das
`x-webhook-secret` (Schritt 4).

### 6. SQL ausführen
Falls noch nicht geschehen: den kompletten Inhalt von `supabase-security.sql`
im Supabase SQL-Editor ausführen (legt u.a. die Tabelle für die Push-Abos an
und den Trigger, der diese Funktion automatisch aufruft).

## Testen

1. App öffnen, einloggen, Benachrichtigungen erlauben (Browser fragt danach)
2. Auf einem ZWEITEN Gerät/Account einen Notfall auslösen
3. Auf dem ersten Gerät sollte innerhalb weniger Sekunden eine Push-
   Benachrichtigung mit Ton ankommen — auch wenn der Browser/Tab zu ist
   (ausprobieren: App-Tab schließen, dann Notfall auslösen)

Falls nichts ankommt: Supabase Dashboard → Edge Functions →
`send-emergency-push` → Logs anschauen, da steht meist genau, woran's liegt.

## Einschränkungen (ehrlich gesagt)

- **iPhone:** Web Push funktioniert nur, wenn die App als "App" auf dem
  Homescreen liegt (Teilen → Zum Home-Bildschirm), nicht wenn sie nur im
  Safari-Tab offen ist. Braucht iOS 16.4 oder neuer.
- **Android:** Funktioniert auch direkt im Chrome-Browser, kein
  "Installieren" nötig (ist aber trotzdem empfehlenswert).
- Braucht **immer noch etwas Internet-Verbindung** in dem Moment, wo der
  Notfall ausgelöst wird UND in dem Moment, wo die Benachrichtigung ankommt.
  Bei wirklich komplett totem Empfang hilft nur noch der SMS-Backup-Weg in
  der App.
- Kostenlos, aber die Zustellung läuft technisch über die Push-Server von
  Apple/Google — die sind zuverlässig, aber nicht 100% garantiert (wie bei
  jeder Push-Benachrichtigung, z.B. auch bei WhatsApp).
