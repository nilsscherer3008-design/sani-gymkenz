// Sani AG – Edge Function: send-emergency-push
// Wird automatisch von einem Datenbank-Trigger aufgerufen, sobald ein neuer
// Notfall in der Tabelle "emergencies" angelegt wird (siehe supabase-security.sql).
// Schickt eine echte Web-Push-Benachrichtigung (mit Ton/Vibration, auch bei
// geschlossener App) an alle registrierten Geräte.

import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC_KEY = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE_KEY = Deno.env.get("VAPID_PRIVATE_KEY")!;
const WEBHOOK_SECRET = Deno.env.get("WEBHOOK_SECRET") ?? "";

webpush.setVapidDetails(
  "mailto:sani-ag@example.com",
  VAPID_PUBLIC_KEY,
  VAPID_PRIVATE_KEY
);

Deno.serve(async (req: Request) => {
  try {
    // Einfacher Schutz: nur der eigene Datenbank-Trigger darf diese Funktion
    // aufrufen (Geheimnis wird als Header mitgeschickt, siehe SQL-Trigger).
    if (WEBHOOK_SECRET && req.headers.get("x-webhook-secret") !== WEBHOOK_SECRET) {
      return new Response("Forbidden", { status: 403 });
    }

    const { emergency } = await req.json();
    if (!emergency) return new Response("Missing emergency", { status: 400 });

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    let query = supabase.from("push_subscriptions").select("*");
    if (emergency.triggered_by) query = query.neq("user_id", emergency.triggered_by);
    const { data: subs, error } = await query;
    if (error) throw error;

    const title = `🚨 NOTFALL von ${emergency.triggered_by_name || "Sani AG"}!`;
    const body = `📍 Ort: ${emergency.location || "-"} | ⚠️ ${emergency.description || "-"}`;
    const payload = JSON.stringify({ title, body });

    let sent = 0, removed = 0;
    await Promise.allSettled(
      (subs ?? []).map(async (s: { id: string; endpoint: string; p256dh: string; auth: string }) => {
        try {
          await webpush.sendNotification(
            { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
            payload
          );
          sent++;
        } catch (err: unknown) {
          // Abo ist ungültig/abgelaufen (z.B. App deinstalliert) -> aufräumen
          const statusCode = (err as { statusCode?: number })?.statusCode;
          if (statusCode === 404 || statusCode === 410) {
            await supabase.from("push_subscriptions").delete().eq("id", s.id);
            removed++;
          }
        }
      })
    );

    return new Response(JSON.stringify({ sent, removed, total: (subs ?? []).length }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
