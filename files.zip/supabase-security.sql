-- ═══════════════════════════════════════════════════════════════════════════
-- Sani AG – Sicherheits-Setup für Supabase (Row Level Security)
-- ═══════════════════════════════════════════════════════════════════════════
--
-- WAS DAS HIER MACHT:
--  1. Verschiebt die Lehrer-/Sekretariat-Zugangscodes aus dem für jeden
--     einsehbaren Quelltext (index.html) in eine geschützte Datenbank-Tabelle.
--  2. Sorgt dafür, dass niemand sich selbst per Browser-Konsole zum Lehrer
--     oder Sekretariat "hochstufen" kann (das ging vorher, weil die App den
--     Code nur im Browser geprüft hat — Supabase selbst hat das nicht
--     kontrolliert).
--  3. Beschränkt Sekretariat-Konten wirklich (nicht nur in der Oberfläche
--     versteckt) auf: Notfälle auslösen — aber NICHT auflösen, NICHT
--     Kalender/Chat/Check-in lesen.
--  4. Nur Lehrer dürfen Termine/Ziele/Check-Einträge anlegen und ändern.
--
-- WIE ANWENDEN:
--  1. In Supabase: Dashboard → SQL Editor → "New query"
--  2. Diesen kompletten Inhalt einfügen und "Run" klicken
--  3. Danach die App einmal komplett neu laden und alle Funktionen testen
--     (einloggen, Termin anlegen als Lehrer, Notfall auslösen, Chat, ...)
--
-- ⚠️ WICHTIG:
--  - Ich kenne eure Tabellen nur aus dem App-Code (index.html), nicht aus der
--    echten Datenbank. Falls Spalten-/Tabellennamen bei euch leicht anders
--    heißen, meldet Supabase beim Ausführen einen Fehler an genau der Stelle
--    — dann bitte kurz Bescheid geben, ich passe es an.
--  - Testet das am besten NICHT während eines laufenden Schultags, sondern
--    z.B. abends, falls doch mal kurz etwas nicht wie erwartet funktioniert.
--  - Falls etwas kaputt geht: ganz unten steht ein NOTFALL-ROLLBACK, der
--    alles wieder abschaltet.
-- ═══════════════════════════════════════════════════════════════════════════


-- ───────────────────────────────────────────────────────────────────────────
-- 0) Spalte für Handynummern (SMS-Backup-Kanal bei schwachem Empfang)
-- ───────────────────────────────────────────────────────────────────────────
alter table profiles add column if not exists phone text;


-- ───────────────────────────────────────────────────────────────────────────
-- 1) Geschützte Tabelle für die Zugangscodes
--    (RLS aktiv, aber KEINE Policies = niemand kann sie direkt lesen/ändern,
--    nur die Funktion claim_role() weiter unten, die mit erhöhten Rechten läuft)
-- ───────────────────────────────────────────────────────────────────────────
create table if not exists role_codes (
  role text primary key,
  code text not null
);
alter table role_codes enable row level security;

insert into role_codes (role, code) values
  ('Lehrer', 'sani2026'),
  ('Sekretariat', 'sekretariat2026')
on conflict (role) do nothing;

-- Code später ändern? Einfach z.B.:
-- update role_codes set code = 'neuerCode2027' where role = 'Sekretariat';
-- (direkt hier im SQL Editor, oder über Dashboard → Table Editor → role_codes)


-- ───────────────────────────────────────────────────────────────────────────
-- 2) Hilfsfunktion: eigene Rolle ermitteln (für die Policies unten)
-- ───────────────────────────────────────────────────────────────────────────
create or replace function my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid();
$$;


-- ───────────────────────────────────────────────────────────────────────────
-- 3) Sichere Funktion zum Freischalten einer Rolle per Code
--    Läuft mit erhöhten Rechten (security definer), damit sie role_codes
--    lesen darf, obwohl normale Nutzer das nicht dürfen.
-- ───────────────────────────────────────────────────────────────────────────
create or replace function claim_role(requested_role text, entered_code text) returns boolean
language plpgsql security definer set search_path = public as $$
declare
  correct_code text;
begin
  if auth.uid() is null then
    raise exception 'Nicht angemeldet';
  end if;
  if requested_role not in ('Lehrer', 'Sekretariat') then
    raise exception 'Ungültige Rolle';
  end if;

  select code into correct_code from role_codes where role = requested_role;
  if correct_code is null or correct_code <> entered_code then
    return false;
  end if;

  update profiles set role = requested_role where id = auth.uid();
  return true;
end;
$$;


-- ───────────────────────────────────────────────────────────────────────────
-- 4) profiles
--    - Alle angemeldeten Nutzer dürfen alle Profile LESEN (Namen im Chat/
--      Kalender werden gebraucht)
--    - Jeder darf nur sein EIGENES Profil anlegen, und dabei nur als "Schüler"
--      (Lehrer/Sekretariat gibt's nur über claim_role())
--    - Jeder darf sein eigenes Profil bearbeiten (z.B. Name), aber NICHT die
--      eigene Rolle selbst hochstufen
-- ───────────────────────────────────────────────────────────────────────────
alter table profiles enable row level security;

drop policy if exists "profiles_select_all" on profiles;
create policy "profiles_select_all" on profiles
  for select to authenticated using (true);

drop policy if exists "profiles_insert_own_as_student" on profiles;
create policy "profiles_insert_own_as_student" on profiles
  for insert to authenticated with check (id = auth.uid() and role = 'Schüler');

drop policy if exists "profiles_update_own_name_only" on profiles;
create policy "profiles_update_own_name_only" on profiles
  for update to authenticated
  using (id = auth.uid())
  with check (id = auth.uid() and role = (select p.role from profiles p where p.id = auth.uid()));


-- ───────────────────────────────────────────────────────────────────────────
-- 5) appointments / goals / check_entries
--    - Lesen: alle außer Sekretariat (die sollen ja NUR den Notfallbutton haben)
--    - Schreiben (anlegen/ändern/löschen): nur Lehrer
-- ───────────────────────────────────────────────────────────────────────────
alter table appointments enable row level security;
drop policy if exists "appts_select_non_sekretariat" on appointments;
create policy "appts_select_non_sekretariat" on appointments for select to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "appts_insert_teacher" on appointments;
create policy "appts_insert_teacher" on appointments for insert to authenticated with check (my_role() = 'Lehrer');
drop policy if exists "appts_update_teacher" on appointments;
create policy "appts_update_teacher" on appointments for update to authenticated using (my_role() = 'Lehrer');
drop policy if exists "appts_delete_teacher" on appointments;
create policy "appts_delete_teacher" on appointments for delete to authenticated using (my_role() = 'Lehrer');

alter table goals enable row level security;
drop policy if exists "goals_select_non_sekretariat" on goals;
create policy "goals_select_non_sekretariat" on goals for select to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "goals_insert_teacher" on goals;
create policy "goals_insert_teacher" on goals for insert to authenticated with check (my_role() = 'Lehrer');
drop policy if exists "goals_update_teacher" on goals;
create policy "goals_update_teacher" on goals for update to authenticated using (my_role() = 'Lehrer');
drop policy if exists "goals_delete_teacher" on goals;
create policy "goals_delete_teacher" on goals for delete to authenticated using (my_role() = 'Lehrer');

alter table check_entries enable row level security;
drop policy if exists "check_select_non_sekretariat" on check_entries;
create policy "check_select_non_sekretariat" on check_entries for select to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "check_insert_non_sekretariat" on check_entries;
create policy "check_insert_non_sekretariat" on check_entries for insert to authenticated with check (my_role() <> 'Sekretariat');
drop policy if exists "check_update_non_sekretariat" on check_entries;
create policy "check_update_non_sekretariat" on check_entries for update to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "check_delete_teacher" on check_entries;
create policy "check_delete_teacher" on check_entries for delete to authenticated using (my_role() = 'Lehrer');


-- ───────────────────────────────────────────────────────────────────────────
-- 6) chat_contacts / chat_messages
--    - Sekretariat darf den Chat gar nicht sehen
--    - Alle anderen dürfen lesen und im eigenen Namen schreiben
-- ───────────────────────────────────────────────────────────────────────────
alter table chat_contacts enable row level security;
drop policy if exists "contacts_select_non_sekretariat" on chat_contacts;
create policy "contacts_select_non_sekretariat" on chat_contacts for select to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "contacts_insert_teacher" on chat_contacts;
create policy "contacts_insert_teacher" on chat_contacts for insert to authenticated with check (my_role() = 'Lehrer');

alter table chat_messages enable row level security;
drop policy if exists "messages_select_non_sekretariat" on chat_messages;
create policy "messages_select_non_sekretariat" on chat_messages for select to authenticated using (my_role() <> 'Sekretariat');
drop policy if exists "messages_insert_own_non_sekretariat" on chat_messages;
create policy "messages_insert_own_non_sekretariat" on chat_messages for insert to authenticated with check (sender_id = auth.uid() and my_role() <> 'Sekretariat');


-- ───────────────────────────────────────────────────────────────────────────
-- 7) emergencies
--    - Lesen: alle (auch Sekretariat — die müssen ja sehen, ob's ausgelöst wurde)
--    - Auslösen (insert): alle, aber nur im eigenen Namen
--    - Auflösen (update, "erledigt"): NICHT Sekretariat — das bleibt den
--      Sanis/Lehrern vorbehalten, wie gewünscht
-- ───────────────────────────────────────────────────────────────────────────
alter table emergencies enable row level security;
drop policy if exists "emergencies_select_all" on emergencies;
create policy "emergencies_select_all" on emergencies for select to authenticated using (true);
drop policy if exists "emergencies_insert_own" on emergencies;
create policy "emergencies_insert_own" on emergencies for insert to authenticated with check (triggered_by = auth.uid());
drop policy if exists "emergencies_update_non_sekretariat" on emergencies;
create policy "emergencies_update_non_sekretariat" on emergencies for update to authenticated using (my_role() <> 'Sekretariat');


-- ───────────────────────────────────────────────────────────────────────────
-- 8) Web Push (echte Benachrichtigungen mit Ton, auch bei geschlossener App)
--    - Tabelle für die Push-Abos jedes Geräts
--    - Automatischer Trigger: sobald ein Notfall eingefügt wird, ruft die
--      Datenbank selbst die Edge Function "send-emergency-push" auf, die dann
--      alle Geräte benachrichtigt. Das läuft serverseitig — hängt NICHT davon
--      ab, dass die Verbindung des auslösenden Handys danach noch hält.
-- ───────────────────────────────────────────────────────────────────────────
create table if not exists push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  created_at timestamptz default now()
);
alter table push_subscriptions enable row level security;
drop policy if exists "push_subs_insert_own" on push_subscriptions;
create policy "push_subs_insert_own" on push_subscriptions for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "push_subs_update_own" on push_subscriptions;
create policy "push_subs_update_own" on push_subscriptions for update to authenticated using (user_id = auth.uid());
drop policy if exists "push_subs_select_own" on push_subscriptions;
create policy "push_subs_select_own" on push_subscriptions for select to authenticated using (user_id = auth.uid());
drop policy if exists "push_subs_delete_own" on push_subscriptions;
create policy "push_subs_delete_own" on push_subscriptions for delete to authenticated using (user_id = auth.uid());
-- (Die Edge Function selbst liest ALLE Abos mit dem service_role-Schlüssel,
--  der umgeht RLS automatisch — dafür braucht es keine extra Policy.)

-- pg_net aktivieren (ermöglicht HTTP-Aufrufe direkt aus einem Datenbank-Trigger)
create extension if not exists pg_net;

-- ⚠️ Du kannst dieses vorgeschlagene Geheimnis übernehmen oder durch ein
-- eigenes ersetzen — Hauptsache es steht hier UND als WEBHOOK_SECRET beim
-- Deployen der Edge Function (siehe supabase-push/README.md) identisch drin.
create or replace function notify_emergency_push() returns trigger
language plpgsql security definer as $$
begin
  perform net.http_post(
    url := 'https://ljxvgqvutawlyjzuhmgc.supabase.co/functions/v1/send-emergency-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-webhook-secret', 'P6Op4W9cGw0VjeNY5GLyjxbB8lcPWCi7'
    ),
    body := jsonb_build_object('emergency', row_to_json(NEW))
  );
  return NEW;
end;
$$;

drop trigger if exists on_emergency_insert_push on emergencies;
create trigger on_emergency_insert_push
  after insert on emergencies
  for each row execute function notify_emergency_push();


-- ═══════════════════════════════════════════════════════════════════════════
-- 🆘 NOTFALL-ROLLBACK — falls nach dem Ausführen etwas nicht mehr geht,
-- diesen Block separat ausführen, um ALLES wieder abzuschalten:
-- ═══════════════════════════════════════════════════════════════════════════
-- alter table profiles disable row level security;
-- alter table appointments disable row level security;
-- alter table goals disable row level security;
-- alter table check_entries disable row level security;
-- alter table chat_contacts disable row level security;
-- alter table chat_messages disable row level security;
-- alter table emergencies disable row level security;
-- alter table role_codes disable row level security;
-- alter table push_subscriptions disable row level security;
-- drop trigger if exists on_emergency_insert_push on emergencies;
